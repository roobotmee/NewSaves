from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

# Association table for many-to-many relationship between users and channels
user_channel = Table(
	'user_channel',
	Base.metadata,
	Column('user_id', Integer, ForeignKey('users.id')),
	Column('channel_id', Integer, ForeignKey('channels.id'))
)

class User(Base):
	__tablename__ = 'users'
	
	id = Column(Integer, primary_key=True)
	telegram_id = Column(Integer, unique=True, nullable=False)
	username = Column(String, nullable=True)
	first_name = Column(String, nullable=True)
	last_name = Column(String, nullable=True)
	is_blocked = Column(Boolean, default=False)
	created_at = Column(DateTime, default=datetime.utcnow)
	last_activity = Column(DateTime, default=datetime.utcnow)
	
	# Relationships
	downloads = relationship("Download", back_populates="user")
	searches = relationship("MusicSearch", back_populates="user")
	channels = relationship("Channel", secondary=user_channel, back_populates="subscribers")
	
	
	def __repr__(self):
		return f"<User(telegram_id={self.telegram_id}, username={self.username})>"

class Channel(Base):
	__tablename__ = 'channels'
	
	id = Column(Integer, primary_key=True)
	channel_id = Column(String, nullable=False)
	title = Column(String, nullable=False)
	invite_link = Column(String, nullable=True)
	is_mandatory = Column(Boolean, default=False)
	added_at = Column(DateTime, default=datetime.utcnow)
	
	# Relationships
	subscribers = relationship("User", secondary=user_channel, back_populates="channels")
	
	
	def __repr__(self):
		return f"<Channel(title={self.title}, mandatory={self.is_mandatory})>"

class Download(Base):
	__tablename__ = 'downloads'
	
	id = Column(Integer, primary_key=True)
	user_id = Column(Integer, ForeignKey('users.id'))
	platform = Column(String, nullable=False)  # 'youtube', 'instagram', 'tiktok', 'snapchat'
	content_url = Column(String, nullable=False)
	file_path = Column(String, nullable=True)
	file_size = Column(Integer, nullable=True)
	status = Column(String, default='pending')  # 'pending', 'completed', 'failed'
	created_at = Column(DateTime, default=datetime.utcnow)
	
	# Relationships
	user = relationship("User", back_populates="downloads")
	
	
	def __repr__(self):
		return f"<Download(platform={self.platform}, status={self.status})>"

class MusicSearch(Base):
	__tablename__ = 'music_searches'
	
	id = Column(Integer, primary_key=True)
	user_id = Column(Integer, ForeignKey('users.id'))
	query = Column(String, nullable=False)
	result_count = Column(Integer, default=0)
	created_at = Column(DateTime, default=datetime.utcnow)
	
	# Relationships
	user = relationship("User", back_populates="searches")
	
	
	def __repr__(self):
		return f"<MusicSearch(query={self.query}, results={self.result_count})>"

class Advertisement(Base):
	__tablename__ = 'advertisements'
	
	id = Column(Integer, primary_key=True)
	content = Column(String, nullable=False)
	is_forward = Column(Boolean, default=False)
	forward_from = Column(String, nullable=True)
	sent_count = Column(Integer, default=0)
	created_at = Column(DateTime, default=datetime.utcnow)
	
	
	def __repr__(self):
		return f"<Advertisement(id={self.id}, sent_count={self.sent_count})>"