from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from datetime import datetime, timedelta
from contextlib import contextmanager

from database.models import Base, User, Channel, Download, MusicSearch, Advertisement
from config import DATABASE_URL

# Create engine
engine = create_engine(DATABASE_URL)
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

def init_db():
	"""Initialize the database"""
	Base.metadata.create_all(engine)
	print("Database initialized")

@contextmanager
def get_db_session():
	"""Get a database session"""
	session = Session()
	try:
		yield session
		session.commit()
	except Exception as e:
		session.rollback()
		raise e
	finally:
		session.close()

def get_user_stats():
	"""Get user statistics"""
	with get_db_session() as session:
		total_users = session.query(User).count()
		
		# Calculate the first day of the current month
		today = datetime.utcnow()
		first_day_of_month = datetime(today.year, today.month, 1)
		
		new_users_this_month = session.query(User).filter(
			User.created_at >= first_day_of_month
		).count()
		
		blocked_users = session.query(User).filter(
			User.is_blocked == True
		).count()
		
		return {
			"total_users": total_users,
			"new_users_this_month": new_users_this_month,
			"blocked_users": blocked_users
		}