"""
Uzbek language messages for the bot
"""

# Start command messages
START_WELCOME = """
👋 Salom, {first_name}!

Media Yuklab olish botiga xush kelibsiz. Men sizga Instagram, YouTube, TikTok va Snapchat'dan videolarni yuklab olishga, shuningdek musiqa qidirishga yordam beraman.

Video yuklab olish uchun menga havola yuboring yoki musiqa qidirish uchun qo'shiq nomini yozing.
"""

START_ADMIN_INFO = "\n\nSiz administratorsiz. Admin paneliga kirish uchun /admin buyrug'ini ishlating."

SUBSCRIPTION_REQUIRED = """
Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling:

{channels}

Barcha kanallarga obuna bo'lganingizdan so'ng, quyidagi tugmani bosing.
"""

SUBSCRIBED_BUTTON = "✅ Men obuna bo'ldim"

# Video download messages
VIDEO_URL_NOT_SUPPORTED = "Kechirasiz, qo'llab-quvvatlanadigan video havolasini aniqlay olmadim. Iltimos, YouTube, Instagram, TikTok yoki Snapchat'dan to'g'ri havola yuboring."

USER_NOT_AUTHORIZED = "Kechirasiz, siz ushbu funksiyadan foydalanish huquqiga ega emassiz."

VIDEO_PROCESSING = "{platform} videongiz qayta ishlanmoqda. Bu bir oz vaqt olishi mumkin..."

VIDEO_BEING_PROCESSED = "{platform} videongiz qayta ishlanmoqda. Tayyor bo'lganda sizga yuboraman."

VIDEO_TOO_LARGE = "Video to'g'ridan-to'g'ri yuborish uchun juda katta ({size:.1f} MB). Tez orada yuklab olish havolasini taqdim etaman."

VIDEO_DOWNLOAD_FAILED = "Kechirasiz, bu {platform} videosini yuklab ololmadim. Iltimos, boshqa havola bilan urinib ko'ring."

VIDEO_DOWNLOAD_ERROR = "Kechirasiz, {platform} videongizni qayta ishlashda xatolik yuz berdi: {error}"

VIDEO_READY = "Mana sizning {platform} videongiz!"

VIDEO_NO_LONGER_AVAILABLE = "Kechirasiz, video fayli endi mavjud emas."

VIDEO_STILL_PROCESSING = "Bu yuklab olish hali ham {status}. Iltimos, kuting yoki keyinroq qayta urinib ko'ring."

# Music search messages
MUSIC_SEARCHING = "🔍 Musiqa qidirilmoqda: \"{query}\"..."

MUSIC_NOT_FOUND = "Kechirasiz, so'rovingizga mos keladigan hech qanday musiqa topa olmadim. Iltimos, boshqa qidiruv so'zini sinab ko'ring."

MUSIC_LISTENING = "🎧 Musiqani aniqlash uchun audioni tinglayapman..."

MUSIC_IDENTIFICATION_FAILED = "Kechirasiz, audiongizda hech qanday musiqa aniqlay olmadim. Iltimos, aniqroq yozuv bilan urinib ko'ring yoki qo'shiq nomini yozing."

MUSIC_IDENTIFICATION_ERROR = "Kechirasiz, musiqani aniqlashda xatolik yuz berdi: {error}"

MUSIC_SEARCH_ERROR = "Kechirasiz, musiqa qidirishda xatolik yuz berdi: {error}"

MUSIC_MORE_RESULTS = "Jami {count} ta natija topildi. Eng yuqori 5 tasi ko'rsatilmoqda. Aniqroq natijalar uchun qidirishni aniqlashtiring."

# Admin panel messages
ADMIN_WELCOME = "Admin paneliga xush kelibsiz. Variantni tanlang:"

ADMIN_STATS_TITLE = "📊 Bot statistikasi 📊"

ADMIN_STATS_USERS = """
👥 Foydalanuvchilar:
  • Jami foydalanuvchilar: {total_users}
  • Bu oydagi yangi foydalanuvchilar: {new_users}
  • Bloklangan foydalanuvchilar: {blocked_users}
"""

ADMIN_STATS_ACTIVITY = """
📥 Faollik:
  • Jami yuklab olishlar: {total_downloads}
  • Jami musiqa qidirishlar: {total_searches}
"""

ADMIN_STATS_CONTENT = """
📢 Kontent:
  • Kanallar: {total_channels}
  • Reklamalar: {total_ads}
"""

ADMIN_NOT_AUTHORIZED = "Kechirasiz, admin paneliga kirish huquqingiz yo'q."

ADMIN_SEND_AD_PROMPT = """
Barcha foydalanuvchilarga yubormoqchi bo'lgan reklama xabarini yuboring.
Bu matn, rasm, video yoki boshqa xabar turi bo'lishi mumkin.
Bekor qilish uchun /cancel yuboring.
"""

ADMIN_ADD_CHANNEL_PROMPT = """
Iltimos, kanal ma'lumotlarini quyidagi formatda yuboring:
@kanal_nomi yoki kanal_id, Kanal nomi, Taklif havolasi (ixtiyoriy), Majburiy (ha/yo'q)

Misol: @misol_kanal, Mening misol kanali, https://t.me/misol_kanal, ha

Bekor qilish uchun /cancel yuboring.
"""

ADMIN_CHANNEL_DELETED = "'{channel_title}' kanali o'chirildi."

ADMIN_CHANNEL_NOT_FOUND = "Kanal topilmadi."

ADMIN_CHANNEL_TOGGLE = "'{channel_title}' kanali endi {status}."

ADMIN_CHANNEL_MANDATORY = "majburiy"

ADMIN_CHANNEL_OPTIONAL = "ixtiyoriy"

ADMIN_CHANNEL_LIST_TITLE = "📢 Kanallar ro'yxati:"

ADMIN_NO_CHANNELS = "Hali hech qanday kanal qo'shilmagan."

# Button texts
BUTTON_YOUTUBE = "🎬 YouTube"
BUTTON_INSTAGRAM = "📸 Instagram"
BUTTON_TIKTOK = "📱 TikTok"
BUTTON_SNAPCHAT = "👻 Snapchat"
BUTTON_SEARCH_MUSIC = "🎵 Musiqa qidirish"
BUTTON_HELP = "ℹ️ Yordam"

BUTTON_STATISTICS = "📊 Statistika"
BUTTON_SEND_AD = "📢 Reklama yuborish"
BUTTON_MANAGE_CHANNELS = "📺 Kanallarni boshqarish"
BUTTON_MANAGE_USERS = "👥 Foydalanuvchilarni boshqarish"

BUTTON_DOWNLOAD = "⬇️ Yuklab olish"
BUTTON_MORE_INFO = "🔍 Ko'proq ma'lumot"
BUTTON_DOWNLOAD_AGAIN = "⬇️ Qayta yuklab olish"

BUTTON_ADD_CHANNEL = "➕ Yangi kanal qo'shish"
BUTTON_DELETE = "🗑️ O'chirish"