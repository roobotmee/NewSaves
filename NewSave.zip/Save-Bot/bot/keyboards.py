from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from localization.messages import (
    BUTTON_YOUTUBE, BUTTON_INSTAGRAM, BUTTON_TIKTOK, BUTTON_SNAPCHAT,
    BUTTON_SEARCH_MUSIC, BUTTON_HELP, BUTTON_STATISTICS, BUTTON_SEND_AD,
    BUTTON_MANAGE_CHANNELS, BUTTON_MANAGE_USERS, SUBSCRIBED_BUTTON,
    BUTTON_DOWNLOAD, BUTTON_MORE_INFO, BUTTON_DOWNLOAD_AGAIN
)

def get_main_menu_keyboard():
    """Get the main menu keyboard"""
    keyboard = [
        [BUTTON_YOUTUBE, BUTTON_INSTAGRAM],
        [BUTTON_TIKTOK, BUTTON_SNAPCHAT],
        [BUTTON_SEARCH_MUSIC, BUTTON_HELP]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_admin_keyboard():
    """Get the admin panel keyboard"""
    keyboard = [
        [
            InlineKeyboardButton(BUTTON_STATISTICS, callback_data="admin_stats"),
            InlineKeyboardButton(BUTTON_SEND_AD, callback_data="admin_send_ad")
        ],
        [
            InlineKeyboardButton(BUTTON_MANAGE_CHANNELS, callback_data="channel_list"),
            InlineKeyboardButton(BUTTON_MANAGE_USERS, callback_data="admin_users")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_subscription_keyboard():
    """Get the subscription check keyboard"""
    keyboard = [
        [InlineKeyboardButton(SUBSCRIBED_BUTTON, callback_data="check_subscription")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_music_result_keyboard(result_id):
    """Get keyboard for music result actions"""
    keyboard = [
        [
            InlineKeyboardButton(BUTTON_DOWNLOAD, callback_data=f"music_download_{result_id}"),
            InlineKeyboardButton(BUTTON_MORE_INFO, callback_data=f"music_info_{result_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_video_download_keyboard(download_id):
    """Get keyboard for video download actions"""
    keyboard = [
        [InlineKeyboardButton(BUTTON_DOWNLOAD_AGAIN, callback_data=f"download_{download_id}")]
    ]
    return InlineKeyboardMarkup(keyboard)