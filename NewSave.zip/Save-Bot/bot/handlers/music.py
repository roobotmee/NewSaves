import os
import tempfile
from telegram import Update
from telegram.ext import ContextTypes
from datetime import datetime

from database.db import get_db_session
from database.models import User, MusicSearch
from services.music import search_music, identify_music_from_audio
from localization.messages import (
	MUSIC_SEARCHING, MUSIC_NOT_FOUND, MUSIC_LISTENING,
	MUSIC_IDENTIFICATION_FAILED, MUSIC_IDENTIFICATION_ERROR,
	MUSIC_SEARCH_ERROR, MUSIC_MORE_RESULTS, USER_NOT_AUTHORIZED
)

async def music_search_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle text messages for music search"""
	query = update.message.text
	user = update.effective_user
	
	# Get user from database
	with get_db_session() as session:
		db_user = session.query(User).filter(User.telegram_id == user.id).first()
		
		if not db_user or db_user.is_blocked:
			await update.message.reply_text(USER_NOT_AUTHORIZED)
			return
		
		# Update last activity
		db_user.last_activity = datetime.utcnow()
		
		# Create music search record
		search = MusicSearch(
			user_id=db_user.id,
			query=query,
			created_at=datetime.utcnow()
		)
		session.add(search)
		session.commit()
	
	# Send searching message
	await update.message.reply_text(MUSIC_SEARCHING.format(query=query))
	
	try:
		# Search for music
		results = await search_music(query)
		
		if not results:
			await update.message.reply_text(MUSIC_NOT_FOUND)
			return
		
		# Update search record with result count
		with get_db_session() as session:
			search = session.query(MusicSearch).filter(MusicSearch.id == search.id).first()
			search.result_count = len(results)
		
		# Send results
		for i, result in enumerate(results[:5]):  # Limit to 5 results
			caption = (
				f"🎵 {result['title']}\n"
				f"👤 {result['artist']}\n"
				f"💿 {result['album']}\n"
				f"⏱️ {result['duration']}"
			)
			
			# Send audio file or preview
			if result.get('audio_file'):
				await update.message.reply_audio(
					audio=open(result['audio_file'], 'rb'),
					caption=caption,
					title=result['title'],
					performer=result['artist'],
					duration=result['duration_seconds'] if 'duration_seconds' in result else None
				)
			else:
				# Send as text with link
				await update.message.reply_text(
					caption + f"\n\n🔗 [Tinglash/Yuklab olish]({result['url']})",
					parse_mode='Markdown'
				)
		
		# If there are more results
		if len(results) > 5:
			await update.message.reply_text(
				MUSIC_MORE_RESULTS.format(count=len(results))
			)
	
	except Exception as e:
		await update.message.reply_text(
			MUSIC_SEARCH_ERROR.format(error=str(e))
		)

async def voice_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle voice messages for music identification"""
	user = update.effective_user
	voice = update.message.voice
	
	# Get user from database
	with get_db_session() as session:
		db_user = session.query(User).filter(User.telegram_id == user.id).first()
		
		if not db_user or db_user.is_blocked:
			await update.message.reply_text(USER_NOT_AUTHORIZED)
			return
		
		# Update last activity
		db_user.last_activity = datetime.utcnow()
	
	# Send processing message
	await update.message.reply_text(MUSIC_LISTENING)
	
	try:
		# Download voice message
		voice_file = await context.bot.get_file(voice.file_id)
		
		with tempfile.NamedTemporaryFile(suffix='.ogg', delete=False) as temp_file:
			await voice_file.download_to_drive(custom_path=temp_file.name)
			temp_path = temp_file.name
		
		# Identify music from audio
		result = await identify_music_from_audio(temp_path)
		
		# Clean up temp file
		os.unlink(temp_path)
		
		if result:
			# Create music search record
			with get_db_session() as session:
				search = MusicSearch(
					user_id=db_user.id,
					query=f"Voice identification: {result['title']}",
					result_count=1,
					created_at=datetime.utcnow()
				)
				session.add(search)
			
			# Send result
			caption = (
				f"🎵 Aniqlangan musiqa:\n\n"
				f"Nomi: {result['title']}\n"
				f"Ijrochi: {result['artist']}\n"
				f"Albom: {result.get('album', 'Noma\'lum')}\n"
				f"Yil: {result.get('year', 'Noma\'lum')}"
			)
			
			if result.get('audio_file'):
				await update.message.reply_audio(
					audio=open(result['audio_file'], 'rb'),
					caption=caption,
					title=result['title'],
					performer=result['artist']
				)
			else:
				# Send as text with link
				await update.message.reply_text(
					caption + f"\n\n🔗 [Tinglash/Yuklab olish]({result['url']})",
					parse_mode='Markdown'
				)
		else:
			await update.message.reply_text(MUSIC_IDENTIFICATION_FAILED)
	
	except Exception as e:
		await update.message.reply_text(
			MUSIC_IDENTIFICATION_ERROR.format(error=str(e))
		)