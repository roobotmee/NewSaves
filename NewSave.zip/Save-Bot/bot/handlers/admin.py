from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from datetime import datetime

from database.db import get_db_session, get_user_stats
from database.models import User, Channel, Advertisement, Download, MusicSearch
from bot.keyboards import get_admin_keyboard
from config import ADMIN_IDS
from localization.messages import (
	ADMIN_WELCOME, ADMIN_STATS_TITLE, ADMIN_STATS_USERS,
	ADMIN_STATS_ACTIVITY, ADMIN_STATS_CONTENT, ADMIN_NOT_AUTHORIZED,
	ADMIN_SEND_AD_PROMPT, ADMIN_ADD_CHANNEL_PROMPT, ADMIN_CHANNEL_DELETED,
	ADMIN_CHANNEL_NOT_FOUND, ADMIN_CHANNEL_TOGGLE, ADMIN_CHANNEL_MANDATORY,
	ADMIN_CHANNEL_OPTIONAL, ADMIN_CHANNEL_LIST_TITLE, ADMIN_NO_CHANNELS,
	BUTTON_ADD_CHANNEL, BUTTON_DELETE
)

# Conversation states
WAITING_FOR_AD, WAITING_FOR_CHANNEL = range(2)

async def admin_panel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle the /admin command"""
	user = update.effective_user
	
	# Check if user is admin
	if user.id not in ADMIN_IDS:
		await update.message.reply_text(ADMIN_NOT_AUTHORIZED)
		return
	
	# Send admin panel
	await update.message.reply_text(
		ADMIN_WELCOME,
		reply_markup=get_admin_keyboard()
	)

async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle the /stats command"""
	user = update.effective_user
	
	# Check if user is admin
	if user.id not in ADMIN_IDS:
		await update.message.reply_text(ADMIN_NOT_AUTHORIZED)
		return
	
	# Get statistics
	stats = get_user_stats()
	
	# Get additional statistics
	with get_db_session() as session:
		total_downloads = session.query(Download).count()
		total_searches = session.query(MusicSearch).count()
		total_channels = session.query(Channel).count()
		total_ads = session.query(Advertisement).count()
	
	# Format statistics message
	stats_message = (
		  ADMIN_STATS_TITLE + "\n\n" +
		  ADMIN_STATS_USERS.format(
			  total_users=stats['total_users'],
			  new_users=stats['new_users_this_month'],
			  blocked_users=stats['blocked_users']
		  ) + "\n" +
		  ADMIN_STATS_ACTIVITY.format(
			  total_downloads=total_downloads,
			  total_searches=total_searches
		  ) + "\n" +
		  ADMIN_STATS_CONTENT.format(
			  total_channels=total_channels,
			  total_ads=total_ads
		  )
	)
	
	await update.message.reply_text(stats_message)

async def send_ad_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle the /sendad command"""
	user = update.effective_user
	
	# Check if user is admin
	if user.id not in ADMIN_IDS:
		await update.message.reply_text(ADMIN_NOT_AUTHORIZED)
		return
	
	await update.message.reply_text(ADMIN_SEND_AD_PROMPT)
	
	# Set conversation state
	context.user_data["state"] = WAITING_FOR_AD
	return WAITING_FOR_AD

async def add_channel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle the /addchannel command"""
	user = update.effective_user
	
	# Check if user is admin
	if user.id not in ADMIN_IDS:
		await update.message.reply_text(ADMIN_NOT_AUTHORIZED)
		return
	
	await update.message.reply_text(ADMIN_ADD_CHANNEL_PROMPT)
	
	# Set conversation state
	context.user_data["state"] = WAITING_FOR_CHANNEL
	return WAITING_FOR_CHANNEL

async def channel_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle callback queries for channel actions"""
	query = update.callback_query
	await query.answer()
	
	# Extract channel ID and action from callback data
	data_parts = query.data.split("_")
	action = data_parts[1]
	channel_id = int(data_parts[2]) if len(data_parts) > 2 else None
	
	# Check if user is admin
	if query.from_user.id not in ADMIN_IDS:
		await query.edit_message_text(ADMIN_NOT_AUTHORIZED)
		return
	
	# Handle different actions
	if action == "delete" and channel_id:
		# Delete channel
		with get_db_session() as session:
			channel = session.query(Channel).filter(Channel.id == channel_id).first()
			if channel:
				channel_title = channel.title
				session.delete(channel)
				await query.edit_message_text(ADMIN_CHANNEL_DELETED.format(channel_title=channel_title))
			else:
				await query.edit_message_text(ADMIN_CHANNEL_NOT_FOUND)
	
	elif action == "toggle" and channel_id:
		# Toggle mandatory status
		with get_db_session() as session:
			channel = session.query(Channel).filter(Channel.id == channel_id).first()
			if channel:
				channel.is_mandatory = not channel.is_mandatory
				status = ADMIN_CHANNEL_MANDATORY if channel.is_mandatory else ADMIN_CHANNEL_OPTIONAL
				await query.edit_message_text(
					ADMIN_CHANNEL_TOGGLE.format(channel_title=channel.title, status=status)
				)
			else:
				await query.edit_message_text(ADMIN_CHANNEL_NOT_FOUND)
	
	elif action == "list":
		# List all channels
		with get_db_session() as session:
			channels = session.query(Channel).all()
			
			if not channels:
				await query.edit_message_text(ADMIN_NO_CHANNELS)
				return
			
			channels_text = ADMIN_CHANNEL_LIST_TITLE + "\n\n"
			for i, channel in enumerate(channels, 1):
				channel_type = ADMIN_CHANNEL_MANDATORY if channel.is_mandatory else ADMIN_CHANNEL_OPTIONAL
				channels_text += (
					f"{i}. *{channel.title}* ({channel.channel_id})\n"
					f"   Status: {channel_type}\n"
					f"   Link: {channel.invite_link or 'N/A'}\n\n"
				)
			
			# Add keyboard for channel management
			keyboard = []
			for channel in channels:
				keyboard.append([
					InlineKeyboardButton(
						f"{'🔒' if channel.is_mandatory else '🔓'} {channel.title}",
						callback_data=f"channel_toggle_{channel.id}"
					),
					InlineKeyboardButton(
						BUTTON_DELETE,
						callback_data=f"channel_delete_{channel.id}"
					)
				])
			
			keyboard.append([InlineKeyboardButton(BUTTON_ADD_CHANNEL, callback_data="channel_add")])
			
			await query.edit_message_text(
				channels_text,
				reply_markup=InlineKeyboardMarkup(keyboard),
				parse_mode='Markdown'
			)
	
	elif action == "add":
		# Redirect to add channel command
		await query.edit_message_text("Yangi kanal qo'shish uchun /addchannel buyrug'idan foydalaning.")