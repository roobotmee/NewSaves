import re
import os
from telegram import Update
from telegram.ext import ContextTypes
from datetime import datetime

from database.db import get_db_session
from database.models import User, Download
from services.youtube import download_youtube_video
from services.instagram import download_instagram_video
from services.tiktok import download_tiktok_video
from services.snapchat import download_snapchat_video
from bot.utils import extract_platform_from_url, format_file_size
from config import DOWNLOAD_PATH, MAX_FILE_SIZE
from localization.messages import (
	VIDEO_URL_NOT_SUPPORTED, USER_NOT_AUTHORIZED, VIDEO_PROCESSING,
	VIDEO_BEING_PROCESSED, VIDEO_TOO_LARGE, VIDEO_DOWNLOAD_FAILED,
	VIDEO_DOWNLOAD_ERROR, VIDEO_READY, VIDEO_NO_LONGER_AVAILABLE,
	VIDEO_STILL_PROCESSING
)

# URL patterns for different platforms
YOUTUBE_PATTERN = r'(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?([^\s&]+)'
INSTAGRAM_PATTERN = r'(?:https?:\/\/)?(?:www\.)?(?:instagram\.com)\/(?:p|reel)\/([^\s\/]+)'
TIKTOK_PATTERN = r'(?:https?:\/\/)?(?:www\.)?(?:tiktok\.com)\/(@[^\/]+)\/video\/(\d+)'
SNAPCHAT_PATTERN = r'(?:https?:\/\/)?(?:www\.)?(?:snapchat\.com)\/(?:add|discover)\/([^\s\/]+)'

async def video_url_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle messages containing video URLs"""
	message_text = update.message.text
	user = update.effective_user
	
	# Check if message contains a supported URL
	youtube_match = re.search(YOUTUBE_PATTERN, message_text)
	instagram_match = re.search(INSTAGRAM_PATTERN, message_text)
	tiktok_match = re.search(TIKTOK_PATTERN, message_text)
	snapchat_match = re.search(SNAPCHAT_PATTERN, message_text)
	
	if not any([youtube_match, instagram_match, tiktok_match, snapchat_match]):
		await update.message.reply_text(VIDEO_URL_NOT_SUPPORTED)
		return
	
	# Get user from database
	with get_db_session() as session:
		db_user = session.query(User).filter(User.telegram_id == user.id).first()
		
		if not db_user or db_user.is_blocked:
			await update.message.reply_text(USER_NOT_AUTHORIZED)
			return
		
		# Update last activity
		db_user.last_activity = datetime.utcnow()
		
		# Determine platform and video ID
		platform = None
		content_url = message_text
		
		if youtube_match:
			platform = "youtube"
			video_id = youtube_match.group(1)
		elif instagram_match:
			platform = "instagram"
			video_id = instagram_match.group(1)
		elif tiktok_match:
			platform = "tiktok"
			video_id = tiktok_match.group(2)
		elif snapchat_match:
			platform = "snapchat"
			video_id = snapchat_match.group(1)
		
		# Create download record
		download = Download(
			user_id=db_user.id,
			platform=platform,
			content_url=content_url,
			status="pending",
			created_at=datetime.utcnow()
		)
		session.add(download)
		session.commit()
		
		# Send processing message
		processing_message = await update.message.reply_text(
			VIDEO_PROCESSING.format(platform=platform)
		)
		
		# Store download ID in context
		context.user_data["download_id"] = download.id
		context.user_data["processing_message_id"] = processing_message.message_id
	
	# Start downloading in background
	await update.message.reply_text(
		VIDEO_BEING_PROCESSED.format(platform=platform)
	)
	
	# Process the video download
	context.application.create_task(
		process_video_download(update, context, platform, content_url, download.id)
	)

async def process_video_download(update: Update, context: ContextTypes.DEFAULT_TYPE, platform, url, download_id):
	"""Process video download in background"""
	try:
		# Download based on platform
		file_path = None
		
		if platform == "youtube":
			file_path = await download_youtube_video(url)
		elif platform == "instagram":
			file_path = await download_instagram_video(url)
		elif platform == "tiktok":
			file_path = await download_tiktok_video(url)
		elif platform == "snapchat":
			file_path = await download_snapchat_video(url)
		
		# Update download record
		with get_db_session() as session:
			download = session.query(Download).filter(Download.id == download_id).first()
			
			if file_path and os.path.exists(file_path):
				file_size = os.path.getsize(file_path)
				download.file_path = file_path
				download.file_size = file_size
				download.status = "completed"
				
				# Send video if size is within limit
				if file_size <= MAX_FILE_SIZE:
					await update.message.reply_video(
						video=open(file_path, 'rb'),
						caption=VIDEO_READY.format(platform=platform)
					)
				else:
					# File too large, send as link or in chunks
					await update.message.reply_text(
						VIDEO_TOO_LARGE.format(size=file_size / (1024 * 1024))
					)
				# Here you would implement logic to upload to a file hosting service
			else:
				download.status = "failed"
				await update.message.reply_text(
					VIDEO_DOWNLOAD_FAILED.format(platform=platform)
				)
	
	except Exception as e:
		# Update download record as failed
		with get_db_session() as session:
			download = session.query(Download).filter(Download.id == download_id).first()
			download.status = "failed"
		
		await update.message.reply_text(
			VIDEO_DOWNLOAD_ERROR.format(platform=platform, error=str(e))
		)

async def process_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle callback queries for video processing"""
	query = update.callback_query
	await query.answer()
	
	# Extract download ID from callback data
	download_id = query.data.split("_")[1]
	
	# Get download from database
	with get_db_session() as session:
		download = session.query(Download).filter(Download.id == download_id).first()
		
		if not download:
			await query.edit_message_text(VIDEO_NO_LONGER_AVAILABLE)
			return
		
		if download.status == "completed" and download.file_path:
			# Send video if it exists
			if os.path.exists(download.file_path):
				await query.message.reply_video(
					video=open(download.file_path, 'rb'),
					caption=VIDEO_READY.format(platform=download.platform)
				)
			else:
				await query.edit_message_text(VIDEO_NO_LONGER_AVAILABLE)
		else:
			await query.edit_message_text(
				VIDEO_STILL_PROCESSING.format(status=download.status)
			)