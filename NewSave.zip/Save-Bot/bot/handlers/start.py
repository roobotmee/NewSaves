from telegram import Update
from telegram.ext import ContextTypes
from datetime import datetime

from database.db import get_db_session
from database.models import User, Channel
from bot.keyboards import get_main_menu_keyboard, get_subscription_keyboard
from bot.utils import check_user_subscriptions
from config import ADMIN_IDS
from localization.messages import (
	START_WELCOME, START_ADMIN_INFO, SUBSCRIPTION_REQUIRED,
	SUBSCRIBED_BUTTON
)

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle the /start command"""
	user = update.effective_user
	
	# Save or update user in database
	with get_db_session() as session:
		db_user = session.query(User).filter(User.telegram_id == user.id).first()
		
		if not db_user:
			# New user
			db_user = User(
				telegram_id=user.id,
				username=user.username,
				first_name=user.first_name,
				last_name=user.last_name,
				created_at=datetime.utcnow(),
				last_activity=datetime.utcnow()
			)
			session.add(db_user)
			
			# Check if user needs to subscribe to mandatory channels
			mandatory_channels = session.query(Channel).filter(Channel.is_mandatory == True).all()
			if mandatory_channels:
				# Send subscription message
				await check_subscriptions(update, context, db_user, mandatory_channels)
				return
		else:
			# Update existing user
			db_user.username = user.username
			db_user.first_name = user.first_name
			db_user.last_name = user.last_name
			db_user.last_activity = datetime.utcnow()
			
			# Check if user is blocked
			if db_user.is_blocked:
				await update.message.reply_text("Kechirasiz, siz botdan foydalanishdan bloklangansiz.")
				return
	
	# Welcome message
	welcome_text = START_WELCOME.format(first_name=user.first_name)
	
	# Add admin info if user is admin
	if user.id in ADMIN_IDS:
		welcome_text += START_ADMIN_INFO
	
	# Send welcome message with main menu
	await update.message.reply_text(
		welcome_text,
		reply_markup=get_main_menu_keyboard()
	)

async def check_subscriptions(update: Update, context: ContextTypes.DEFAULT_TYPE, user, mandatory_channels):
	"""Check if user is subscribed to all mandatory channels"""
	channels_text = ""
	for channel in mandatory_channels:
		channels_text += f"• {channel.title}\n"
	
	await update.message.reply_text(
		SUBSCRIPTION_REQUIRED.format(channels=channels_text),
		reply_markup=get_subscription_keyboard()
	)

async def subscription_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	"""Handle subscription check callback"""
	query = update.callback_query
	await query.answer()
	
	user = update.effective_user
	
	# Check if user is subscribed to all mandatory channels
	is_subscribed = await check_user_subscriptions(user.id, context.bot)
	
	if is_subscribed:
		# User is subscribed, send welcome message
		welcome_text = START_WELCOME.format(first_name=user.first_name)
		
		# Add admin info if user is admin
		if user.id in ADMIN_IDS:
			welcome_text += START_ADMIN_INFO
		
		await query.edit_message_text(
			welcome_text,
			reply_markup=get_main_menu_keyboard()
		)
	else:
		# User is not subscribed, remind them to subscribe
		with get_db_session() as session:
			mandatory_channels = session.query(Channel).filter(Channel.is_mandatory == True).all()
			
			channels_text = ""
			for channel in mandatory_channels:
				channels_text += f"• {channel.title}\n"
			
			await query.edit_message_text(
				SUBSCRIPTION_REQUIRED.format(channels=channels_text),
				reply_markup=get_subscription_keyboard()
			)