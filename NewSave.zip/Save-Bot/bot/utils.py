import re
from telegram import Bot
from database.db import get_db_session
from database.models import User, Channel

async def check_user_subscriptions(user_id: int, bot: Bot):
	"""Check if user is subscribed to all mandatory channels"""
	with get_db_session() as session:
		# Get all mandatory channels
		mandatory_channels = session.query(Channel).filter(Channel.is_mandatory == True).all()
		
		if not mandatory_channels:
			return True  # No mandatory channels, user is considered subscribed
		
		# Check each channel
		for channel in mandatory_channels:
			try:
				chat_member = await bot.get_chat_member(chat_id=channel.channel_id, user_id=user_id)
				status = chat_member.status
				
				# If user is not a member or is left/kicked, they are not subscribed
				if status in ['left', 'kicked', 'restricted']:
					return False
			except Exception as e:
				print(f"Error checking subscription for channel {channel.title}: {e}")
				# If we can't check, assume not subscribed to be safe
				return False
		
		# User is subscribed to all mandatory channels
		return True

def extract_platform_from_url(url: str):
	"""Extract platform name from URL"""
	if re.search(r'(?:youtube\.com|youtu\.be)', url, re.IGNORECASE):
		return "youtube"
	elif re.search(r'instagram\.com', url, re.IGNORECASE):
		return "instagram"
	elif re.search(r'tiktok\.com', url, re.IGNORECASE):
		return "tiktok"
	elif re.search(r'snapchat\.com', url, re.IGNORECASE):
		return "snapchat"
	else:
		return None

def format_file_size(size_bytes):
	"""Format file size from bytes to human-readable format"""
	if size_bytes < 1024:
		return f"{size_bytes} B"
	elif size_bytes < 1024 * 1024:
		return f"{size_bytes / 1024:.1f} KB"
	elif size_bytes < 1024 * 1024 * 1024:
		return f"{size_bytes / (1024 * 1024):.1f} MB"
	else:
		return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"