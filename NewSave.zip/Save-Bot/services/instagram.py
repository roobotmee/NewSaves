import os
import asyncio
import tempfile
import instaloader
from config import DOWNLOAD_PATH, INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD

async def download_instagram_video(url):
	"""Download video from Instagram"""
	# Extract post shortcode from URL
	shortcode = url.split("/p/")[-1].split("/")[0] if "/p/" in url else url.split("/reel/")[-1].split("/")[0]
	output_path = os.path.join(DOWNLOAD_PATH, f"instagram_{shortcode}.mp4")
	
	# Check if file already exists
	if os.path.exists(output_path):
		return output_path
	
	# Create a temporary directory for download
	with tempfile.TemporaryDirectory() as tmpdir:
		# Run download in a separate thread to avoid blocking
		loop = asyncio.get_event_loop()
		
		
		def download():
			L = instaloader.Instaloader(
				dirname_pattern=tmpdir,
				filename_pattern=shortcode,
				download_video_thumbnails=False,
				download_geotags=False,
				download_comments=False,
				save_metadata=False
			)
			
			# Login if credentials are provided
			if INSTAGRAM_USERNAME and INSTAGRAM_PASSWORD:
				try:
					L.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD)
				except Exception as e:
					print(f"Instagram login failed: {e}")
			
			# Download the post
			post = instaloader.Post.from_shortcode(L.context, shortcode)
			L.download_post(post, target=shortcode)
			
			# Find the downloaded video file
			for file in os.listdir(tmpdir):
				if file.endswith(".mp4"):
					video_path = os.path.join(tmpdir, file)
					# Copy to output path
					with open(video_path, "rb") as src, open(output_path, "wb") as dst:
						dst.write(src.read())
					return output_path
			
			raise Exception("No video found in Instagram post")
		
		
		# Execute download
		try:
			result = await loop.run_in_executor(None, download)
			return result
		except Exception as e:
			print(f"Instagram download error: {e}")
			return None