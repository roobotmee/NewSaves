import os
import asyncio
import yt_dlp
from config import DOWNLOAD_PATH

async def download_youtube_video(url):
	"""Download video from YouTube"""
	# Create a unique filename based on video ID
	video_id = url.split("v=")[-1].split("&")[0] if "v=" in url else url.split("/")[-1]
	output_path = os.path.join(DOWNLOAD_PATH, f"youtube_{video_id}.mp4")
	
	# Check if file already exists
	if os.path.exists(output_path):
		return output_path
	
	# Options for yt-dlp
	ydl_opts = {
		'format': 'best[ext=mp4]/best',
		'outtmpl': output_path,
		'noplaylist': True,
		'quiet': True,
		'no_warnings': True,
	}
	
	# Run download in a separate thread to avoid blocking
	loop = asyncio.get_event_loop()
	
	
	def download():
		with yt_dlp.YoutubeDL(ydl_opts) as ydl:
			ydl.download([url])
		return output_path
	
	
	# Execute download
	result = await loop.run_in_executor(None, download)
	
	return result