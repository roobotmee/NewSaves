import os
import asyncio
import yt_dlp
from config import DOWNLOAD_PATH

async def download_tiktok_video(url):
	"""Download video from TikTok"""
	# Extract video ID from URL
	video_id = url.split("/video/")[-1].split("?")[0]
	output_path = os.path.join(DOWNLOAD_PATH, f"tiktok_{video_id}.mp4")
	
	# Check if file already exists
	if os.path.exists(output_path):
		return output_path
	
	# Options for yt-dlp
	ydl_opts = {
		'format': 'best',
		'outtmpl': output_path,
		'quiet': True,
		'no_warnings': True,
	}
	
	# Run download in a separate thread to avoid blocking
	loop = asyncio.get_event_loop()
	
	
	def download():
		with yt_dlp.YoutubeDL(ydl_opts) as ydl:
			ydl.download([url])
		return output_path
	
	
	# Execute download
	try:
		result = await loop.run_in_executor(None, download)
		return result
	except Exception as e:
		print(f"TikTok download error: {e}")
		return None